N = 500;            % # of unknowns 
r = 0.6*lambda_;    % radius of cylinders
