How to run the code
1. change the geometry / # of unknowns in the scatter_geometry.m
2. run scatter_2D_Ez.m or scatter_2D_Hz.m , for TM/TE case, respectively.
